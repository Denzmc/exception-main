package task1719;

public interface Bean {   // это интерфейс-маркер
}
