package task1710;

public enum Sex {
    MALE,
    FEMALE
}
