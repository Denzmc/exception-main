package task1631.common;

public enum ImageTypes {
    BMP,
    JPG,
    PNG
}
