package task1631.common;

public interface ImageReader {
}
